extends Node2D
## Giao dien + dieu khien co vua 5D.
## Quan co ve bang vector (silhouette + vien + bong do) theo phong cach anh tham chieu.

const Game5D = preload("res://game.gd")
const AIBrain = preload("res://ai.gd")

const N := 8
const CELL := 56.0
const BOARD := CELL * 8.0
const GAP := 120.0
const STEP := BOARD + GAP
const MIN_ZOOM := 0.03
const MAX_ZOOM := 3.0
const UI_FONT := 24

const LIGHT := Color(0.965, 0.867, 0.753)
const DARK := Color(0.769, 0.353, 0.259)
const FRAME_PAST := Color(0.30, 0.13, 0.10)
const FRAME_HEAD := Color(0.45, 0.48, 0.66)
const FRAME_MINE := Color(1.0, 0.80, 0.20)
const PIECE_W := Color(0.99, 0.99, 0.98)
const EDGE_W := Color(0.07, 0.07, 0.11)
const DETAIL_W := Color(0.18, 0.18, 0.25)
const PIECE_B := Color(0.17, 0.18, 0.29)
const EDGE_B := Color(0.05, 0.05, 0.09)
const DETAIL_B := Color(0.80, 0.83, 0.97)
const SHADOW := Color(0, 0, 0, 0.28)

var game: Game5D = Game5D.new()
var camera: Camera2D
var status: Label            # chi con la thong bao ngan (toast) o giua duoi man hinh
var win_panel: PanelContainer
var win_label: Label
var ui_layer: CanvasLayer
var _toast_id := 0
var end_mark := Vector4i(-1, -1, -1, -1)   # o Vua bi an / Vua cua ben thua (danh dau do)
var _end_focused := false
var _end_token := 0             # tang khi van moi, de huy cac coroutine ket thuc van cu
var replay_active := false      # dang phat lai nuoc an Vua
var replay_t := 0.0
var replay_from := Vector2.ZERO
var replay_to := Vector2.ZERO
var replay_piece := 0
var _replay_tw: Tween
var move_sfx: AudioStreamPlayer
var zoom_panel: PanelContainer
var menu_panel: PanelContainer
var zoom_slider: HSlider
var zoom_label: Label
var sel := Vector4i.ZERO
var has_sel := false
var targets: Array = []
var history: Array = []
var msg := ""
var ai: AIBrain = AIBrain.new()
var ai_on := true
var ai_label: Label
var last_moves: Array = []
var _ai_busy := false
var overlay: Node2D
var _views: Dictionary = {}   # Vector2i(l, t) -> Node2D (moi ban co la 1 node, tu cat bo ngoai man hinh)
var _board_tex: ImageTexture   # nen ban co 8x8 -> 1 lenh ve thay vi 33
var _stale := false            # co ban co dang ve o muc chi tiet cu (ve lai dan, khong dong loat)
var gold_btn: Button
var _gold_key := Vector2i(-999, -999)
var _ai_token := 0
var _game_recorded := false

# ---- Multiplayer (WebSocket relay) ----
# Đổi URL này thành địa chỉ server relay của bạn (xem file server)
const RELAY_URL := "ws://127.0.0.1:8080"   # ví dụ: "wss://chess5d-relay.onrender.com"
var ws: WebSocketPeer = WebSocketPeer.new()
var mp_name := "Người chơi"
var mp_room := ""
var mp_player_id := 0          # 1 = host (Trắng), 2 = guest (Đen)
var mp_opponent := ""
var mp_connected := false
var mp_my_color := 0           # Game5D.WHITE or BLACK
var mp_active := false         # đang trong ván multiplayer
var mp_panel: PanelContainer
var mp_status: Label
var name_edit: LineEdit
var room_edit: LineEdit
var create_btn: Button
var join_btn: Button
var leave_btn: Button

var _shapes: Dictionary = {}
var _lod := 0            # 0 = day du, 1 = bo bong/chi tiet, 2 = chi ve tron (zoom xa)
var _pressed := false
var _dragging := false
var _press_pos := Vector2.ZERO
var _touches: Dictionary = {}
var _pinch_dist := 0.0
var _pinch_mid := Vector2.ZERO


func _ready() -> void:
    RenderingServer.set_default_clear_color(Color(0.07, 0.08, 0.12))
    camera = Camera2D.new()
    add_child(camera)
    camera.make_current()
    _setup_sound()
    overlay = Node2D.new()
    overlay.z_index = 10
    add_child(overlay)
    overlay.draw.connect(_draw_overlay)
    ai.load_brain()
    _build_shapes()
    _build_board_tex()
    _build_ui()
    _build_win()
    _build_mp_ui()
    _start_new()


func _notification(what: int) -> void:
    if what == NOTIFICATION_APPLICATION_FOCUS_OUT:
        _touches.clear()
        _pressed = false
    elif what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_WM_CLOSE_REQUEST:
        ai.save_brain()


# ================================================================ HINH DANG QUAN CO

func _p(v: Array) -> PackedVector2Array:
    var out := PackedVector2Array()
    for i in range(0, v.size(), 2):
        out.append(Vector2(v[i], v[i + 1]))
    return out


func _ellipse(cx: float, cy: float, rx: float, ry: float, n: int = 18) -> PackedVector2Array:
    var out := PackedVector2Array()
    for i in n:
        var a := TAU * float(i) / float(n)
        out.append(Vector2(cx + cos(a) * rx, cy + sin(a) * ry))
    return out


## Tam giac hoa 1 lan luc khoi dong -> ve quan chi con 3 lenh draw_mesh, khong ton CPU chia tam giac.
func _make_mesh(polys: Array) -> ArrayMesh:
    var verts := PackedVector2Array()
    var idxs := PackedInt32Array()
    for p in polys:
        var tri: PackedInt32Array = Geometry2D.triangulate_polygon(p)
        var base := verts.size()
        verts.append_array(p)
        for i in tri:
            idxs.append(base + i)
    if idxs.is_empty():
        return null
    var arr: Array = []
    arr.resize(Mesh.ARRAY_MAX)
    arr[Mesh.ARRAY_VERTEX] = verts
    arr[Mesh.ARRAY_INDEX] = idxs
    var m := ArrayMesh.new()
    m.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arr)
    return m


func _add_shape(kind: int, parts: Array, lines: Array = [], dots: Array = []) -> void:
    var outer: Array = []
    for p in parts:
        var res: Array = Geometry2D.offset_polygon(p, 3.0, Geometry2D.JOIN_ROUND)
        if res.is_empty():
            outer.append(p)
        else:
            for q in res:
                outer.append(q)
    _shapes[kind] = {"parts": parts, "outer": outer, "lines": lines, "dots": dots,
        "m_outer": _make_mesh(outer), "m_fill": _make_mesh(parts)}


## Moi quan duoc thiet ke trong o 100x100 (goc tren-trai), y huong xuong.
func _build_shapes() -> void:
    var base := _p([18, 92, 82, 92, 82, 84, 76, 78, 24, 78, 18, 84])
    var plate := _p([26, 72, 74, 72, 74, 80, 26, 80])

    _add_shape(Game5D.PAWN, [
        _ellipse(50, 31, 13, 13),
        _p([38, 43, 62, 43, 62, 50, 38, 50]),
        _p([42, 50, 58, 50, 64, 66, 70, 80, 30, 80, 36, 66]),
        base])

    _add_shape(Game5D.ROOK, [
        _p([26, 16, 36, 16, 36, 24, 44, 24, 44, 16, 56, 16, 56, 24, 64, 24, 64, 16, 74, 16, 74, 36, 26, 36]),
        _p([30, 36, 70, 36, 66, 72, 34, 72]),
        plate, base],
        [_p([30, 36, 70, 36])])

    _add_shape(Game5D.BISHOP, [
        _ellipse(50, 10, 4.5, 4.5, 12),
        _ellipse(50, 32, 14, 20),
        _p([36, 50, 64, 50, 62, 58, 38, 58]),
        _p([40, 58, 60, 58, 68, 76, 32, 76]),
        plate, base],
        [_p([57, 22, 46, 36])])

    _add_shape(Game5D.KNIGHT, [
        _p([26, 80, 30, 66, 40, 54, 34, 50, 26, 52, 18, 46, 16, 38, 22, 30, 30, 26, 34, 14, 40, 6, 46, 16, 56, 20, 66, 30, 72, 46, 74, 62, 74, 80]),
        plate, base],
        [_p([56, 26, 64, 38, 66, 52])],
        [Vector3(34, 32, 2.6), Vector3(19, 39, 1.8)])

    _add_shape(Game5D.KING, [
        _p([46, 2, 54, 2, 54, 8, 60, 8, 60, 15, 54, 15, 54, 26, 46, 26, 46, 15, 40, 15, 40, 8, 46, 8]),
        _p([30, 24, 70, 24, 72, 34, 66, 54, 34, 54, 28, 34]),
        _p([36, 54, 64, 54, 69, 76, 31, 76]),
        plate, base],
        [_p([29, 36, 71, 36])])

    _add_shape(Game5D.QUEEN, [
        _p([24, 24, 30, 38, 37, 16, 43, 34, 50, 12, 57, 34, 63, 16, 70, 38, 76, 24, 70, 58, 30, 58]),
        _ellipse(24, 21, 4, 4, 10),
        _ellipse(37, 13, 4, 4, 10),
        _ellipse(50, 9, 4, 4, 10),
        _ellipse(63, 13, 4, 4, 10),
        _ellipse(76, 21, 4, 4, 10),
        _p([36, 58, 64, 58, 70, 76, 30, 76]),
        plate, base],
        [_p([31, 47, 69, 47])])


# ================================================================ UI

## Am thanh danh quan (sounds/move.mp3). Thu load() truoc; neu chua duoc import thi doc truc tiep file.
func _setup_sound() -> void:
    move_sfx = AudioStreamPlayer.new()
    var path := "res://sounds/move.mp3"
    var stream: AudioStream = null
    if ResourceLoader.exists(path):
        stream = load(path)
    elif FileAccess.file_exists(path):
        var f := FileAccess.open(path, FileAccess.READ)
        if f != null:
            var mp3 := AudioStreamMP3.new()
            mp3.data = f.get_buffer(f.get_length())
            stream = mp3
    move_sfx.stream = stream
    add_child(move_sfx)


func _play_move() -> void:
    if move_sfx != null and move_sfx.stream != null:
        move_sfx.play()


func _build_win() -> void:
    win_panel = PanelContainer.new()
    win_panel.set_anchors_preset(Control.PRESET_CENTER_TOP)
    win_panel.offset_top = 24
    win_panel.grow_horizontal = Control.GROW_DIRECTION_BOTH
    win_panel.grow_vertical = Control.GROW_DIRECTION_END
    win_panel.custom_minimum_size = Vector2(440, 0)
    win_panel.visible = false
    ui_layer.add_child(win_panel)
    var v := VBoxContainer.new()
    v.add_theme_constant_override("separation", 24)
    win_panel.add_child(v)
    win_label = Label.new()
    win_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    win_label.add_theme_font_size_override("font_size", 64)
    win_label.add_theme_color_override("font_outline_color", Color.BLACK)
    win_label.add_theme_constant_override("outline_size", 12)
    v.add_child(win_label)
    _btn(v, "Ván mới", _start_new)


## Khi van ket thuc: tu dong chinh camera den ban co noi Vua bi an (hoac Vua cua ben thua) va danh dau do.
func _focus_loss() -> void:
    var cell: Vector4i = game.end_cell
    if cell.x >= 0:
        var src: Vector4i = game.end_src
        if src.x >= 0:
            _start_replay(src, cell, game.end_piece)
        else:
            end_mark = cell
            _fit_rect(_board_rect(cell.z, cell.w))
        return
    if game.strict_check:
        _mate_replay()
        return
    _focus_king(-game.winner)


func _focus_king(loser: int) -> void:
    var pt: int = game.present_t()
    var best := Vector4i(-1, -1, -1, -1)
    for l in game.active_ls():
        var t: int = game.head_t(l)
        var b := game.board_at(l, t)
        for i in N * N:
            if b[i] == Game5D.KING * loser and (best.x < 0 or t == pt):
                best = Vector4i(i % 8, i >> 3, l, t)
    if best.x >= 0:
        end_mark = best
        _fit_rect(_board_rect(best.z, best.w))
    else:
        _fit_present()


## Luat chieu bat: Vua khong bao gio bi an that. Khi het nuoc thoat, tu dong "choi tiep" nuoc cuoi cua ben thua
## roi nuoc an Vua cua ben thang tren van that, sau do phat lai duong di nhu khi an Vua.
func _mate_replay() -> void:
    var token := _end_token
    var loser := -game.winner
    var res: Array = await _find_mate_attack(loser)
    if token != _end_token:
        return
    if res.is_empty():
        _focus_king(loser)
        return
    replay_active = true
    win_panel.visible = false
    msg = "Chiếu hết! Vua không còn đường thoát."
    _refresh()
    for mv in res[0]:
        var d: Vector4i = mv[1]
        _fit_rect(_board_rect(d.z, d.w))
        await get_tree().create_timer(0.5).timeout
        if token != _end_token:
            return
        game.apply_move(mv[0], mv[1])
        _play_move()
        _refresh()
        await get_tree().create_timer(0.7).timeout
        if token != _end_token:
            return
    var att: Array = res[1]
    game.apply_move(att[0], att[1])
    _refresh()
    _start_replay(att[0], att[1], att[2])


## Tra ve [[nuoc cuoi cua ben thua...], [src, dst, quan an Vua]] hoac [] neu ben thua van con nuoc thoat.
func _find_mate_attack(loser: int) -> Array:
    var token := _end_token
    var g: Game5D = game.clone()
    g.winner = 0
    g.turn_color = loser
    if g.can_submit():
        var att0: Array = g.find_king_attack(loser)
        if att0.is_empty():
            return []
        return [[], att0]
    var first: Array = []
    var tested := 0
    var t0 := Time.get_ticks_usec()
    for l in g.active_ls():
        var t: int = g.head_t(l)
        if g.color_at_t(t) != loser:
            continue
        var b := g.board_at(l, t)
        for i in N * N:
            var v: int = b[i]
            if v == 0 or signi(v) != loser:
                continue
            var src := Vector4i(i % 8, i >> 3, l, t)
            for dst in g.moves_for(src):
                var tok: Dictionary = g.apply_move(src, dst)
                if g.winner == 0 and g.can_submit():
                    var att: Array = g.find_king_attack(loser)
                    if att.is_empty():
                        return []                  # con nuoc thoat -> khong phai chieu het
                    if first.is_empty():
                        first = [[[src, dst]], att]
                g.undo_move(tok)
                tested += 1
                if tested >= 250:
                    return first
                if Time.get_ticks_usec() - t0 > 5000:
                    await get_tree().process_frame
                    if token != _end_token:
                        return []
                    t0 = Time.get_ticks_usec()
    return first


## Phat lai nuoc an Vua: thu nho de thay ca 2 ban, quan an di tu o xuat phat toi Vua, roi phong vao ban co Vua bi an.
func _start_replay(src: Vector4i, dst: Vector4i, piece: int) -> void:
    if _replay_tw != null:
        _replay_tw.kill()
    replay_active = true
    replay_t = 0.0
    replay_piece = piece
    replay_from = _cell_rect(src).get_center()
    replay_to = _cell_rect(dst).get_center()
    end_mark = Vector4i(-1, -1, -1, -1)
    win_panel.visible = false
    _clear_sel()
    _fit_rect(_board_rect(src.z, src.w).merge(_board_rect(dst.z, dst.w)))
    var dur := clampf(0.7 + replay_from.distance_to(replay_to) / 2500.0, 0.9, 2.4)
    _replay_tw = create_tween()
    _replay_tw.tween_interval(0.7)
    _replay_tw.tween_method(_set_replay, 0.0, 1.0, dur).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
    _replay_tw.tween_callback(_replay_arrive.bind(dst))
    _replay_tw.tween_interval(0.7)
    _replay_tw.tween_callback(_replay_finish.bind(dst))
    overlay.queue_redraw()


func _set_replay(t: float) -> void:
    replay_t = t
    overlay.queue_redraw()


func _replay_arrive(dst: Vector4i) -> void:
    end_mark = dst
    _play_move()
    overlay.queue_redraw()


func _replay_finish(dst: Vector4i) -> void:
    replay_active = false
    win_panel.visible = game.winner != 0
    var z0 := camera.zoom
    var p0 := camera.position
    _fit_rect(_board_rect(dst.z, dst.w))
    var z1 := camera.zoom
    var p1 := camera.position
    camera.zoom = z0
    camera.position = p0
    _replay_tw = create_tween()
    _replay_tw.tween_method(_lerp_cam.bind(z0, p0, z1, p1), 0.0, 1.0, 0.6).set_trans(Tween.TRANS_SINE)
    overlay.queue_redraw()


func _lerp_cam(t: float, z0: Vector2, p0: Vector2, z1: Vector2, p1: Vector2) -> void:
    camera.zoom = z0.lerp(z1, t)
    camera.position = p0.lerp(p1, t)
    _after_zoom()


func _hide_toast(tid: int) -> void:
    if tid == _toast_id:
        msg = ""
        status.visible = false


func _build_ui() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)
    ui_layer = layer

    status = Label.new()
    status.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
    status.offset_left = 14
    status.offset_right = -14
    status.offset_top = -200
    status.offset_bottom = -104
    status.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    status.vertical_alignment = VERTICAL_ALIGNMENT_BOTTOM
    status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    status.add_theme_font_size_override("font_size", 26)
    status.add_theme_color_override("font_outline_color", Color.BLACK)
    status.add_theme_constant_override("outline_size", 8)
    status.visible = false
    layer.add_child(status)

    # ---- thanh duoi
    var bar := HBoxContainer.new()
    bar.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
    bar.offset_left = 8
    bar.offset_right = -8
    bar.offset_top = -88
    bar.offset_bottom = -8
    bar.add_theme_constant_override("separation", 8)
    layer.add_child(bar)
    _btn(bar, "Kết thúc lượt", _on_submit)
    gold_btn = _btn(bar, "Bàn vàng", _on_gold)
    _btn(bar, "Hoàn tác", _on_undo)
    _btn(bar, "Thu phóng", _toggle_zoom_panel)
    _btn(bar, "Menu", _toggle_menu_panel)

    # ---- menu thu phong
    zoom_panel = _make_panel(layer)
    var zv := VBoxContainer.new()
    zv.add_theme_constant_override("separation", 10)
    zoom_panel.add_child(zv)
    zoom_label = Label.new()
    zoom_label.add_theme_font_size_override("font_size", UI_FONT)
    zv.add_child(zoom_label)
    zoom_slider = HSlider.new()
    zoom_slider.min_value = MIN_ZOOM
    zoom_slider.max_value = MAX_ZOOM
    zoom_slider.step = 0.001
    zoom_slider.exp_edit = true
    zoom_slider.value = 0.5
    zoom_slider.custom_minimum_size = Vector2(0, 64)
    zoom_slider.value_changed.connect(_on_zoom_slider)
    zv.add_child(zoom_slider)
    var row1 := HBoxContainer.new()
    row1.add_theme_constant_override("separation", 8)
    zv.add_child(row1)
    _btn(row1, "−", _on_zoom_out)
    _btn(row1, "+", _on_zoom_in)
    _btn(row1, "1 bảng", _fit_one)
    var row2 := HBoxContainer.new()
    row2.add_theme_constant_override("separation", 8)
    zv.add_child(row2)
    _btn(row2, "Present", _fit_present)
    _btn(row2, "Toàn cảnh", _fit_all)
    _btn(row2, "Đóng", _toggle_zoom_panel)

    # ---- menu chung
    menu_panel = _make_panel(layer)
    var mv := VBoxContainer.new()
    mv.add_theme_constant_override("separation", 10)
    menu_panel.add_child(mv)
    var chk := CheckButton.new()
    chk.text = "Luật chiếu (cấm để Vua bị chiếu)"
    chk.button_pressed = true
    chk.add_theme_font_size_override("font_size", UI_FONT)
    chk.custom_minimum_size = Vector2(0, 64)
    chk.toggled.connect(_on_check_toggled)
    mv.add_child(chk)
    var ai_chk := CheckButton.new()
    ai_chk.text = "Chơi với AI (AI cầm quân Đen)"
    ai_chk.button_pressed = true
    ai_chk.add_theme_font_size_override("font_size", UI_FONT)
    ai_chk.custom_minimum_size = Vector2(0, 64)
    ai_chk.toggled.connect(_on_ai_toggled)
    mv.add_child(ai_chk)
    ai_label = Label.new()
    ai_label.add_theme_font_size_override("font_size", 20)
    ai_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    mv.add_child(ai_label)
    _btn(mv, "Xóa trí nhớ AI", _on_ai_reset)
    _btn(mv, "Ván mới", _start_new)
    _btn(mv, "Đầu hàng", _on_resign)
    _btn(mv, "Đóng", _toggle_menu_panel)


func _make_panel(layer: CanvasLayer) -> PanelContainer:
    var p := PanelContainer.new()
    p.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
    p.offset_left = 8
    p.offset_right = -8
    p.offset_top = -100
    p.offset_bottom = -100
    p.grow_vertical = Control.GROW_DIRECTION_BEGIN
    p.visible = false
    layer.add_child(p)
    return p


func _btn(parent: Control, text: String, cb: Callable) -> Button:
    var b := Button.new()
    b.text = text
    b.custom_minimum_size = Vector2(0, 72)
    b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    b.add_theme_font_size_override("font_size", UI_FONT)
    b.pressed.connect(cb)
    parent.add_child(b)
    return b


func _toggle_zoom_panel() -> void:
    menu_panel.visible = false
    zoom_panel.visible = not zoom_panel.visible
    _after_zoom()


func _toggle_menu_panel() -> void:
    zoom_panel.visible = false
    menu_panel.visible = not menu_panel.visible
    _update_ai_label()


func _on_submit() -> void:
    if _ai_locked():
        return
    var err := game.submit()
    if err == "":
        history.clear()
        msg = ""
        _clear_sel()
        _center_present()
        _refresh()
        _maybe_ai()
        return
    msg = err
    _refresh()


func _on_undo() -> void:
    if _ai_locked():
        return
    if history.is_empty():
        msg = "Không còn nước nào để hoàn tác trong lượt này."
    else:
        game.restore(history.pop_back())
        msg = ""
    _clear_sel()
    _refresh()


func _on_resign() -> void:
    menu_panel.visible = false
    if game.winner == 0:
        if mp_active and mp_connected:
            game.winner = -mp_my_color
            _ws_send({"type": "resign"})
            msg = "Bạn đã đầu hàng."
            _toast(msg)
        else:
            game.winner = Game5D.BLACK if ai_on else -game.turn_color
        _ai_token += 1
        _ai_busy = false
    _clear_sel()
    _refresh()


func _on_check_toggled(on: bool) -> void:
    game.strict_check = on
    msg = "Luật chiếu BẬT." if on else "Luật chiếu TẮT: thắng khi bắt được Vua."
    _refresh()


func _start_new() -> void:
    menu_panel.visible = false
    if mp_active:
        # Trong multiplayer, "Ván mới" chỉ reset bàn nếu cả hai đồng ý (tạm thời chỉ reset local + thông báo)
        pass
    _ai_token += 1
    _ai_busy = false
    ai.cancel()
    _game_recorded = false
    ai.trajectory.clear()
    last_moves = []
    end_mark = Vector4i(-1, -1, -1, -1)
    _end_focused = false
    _end_token += 1
    if _replay_tw != null:
        _replay_tw.kill()
    replay_active = false
    game.new_game()
    history.clear()
    _clear_sel()
    msg = ""
    _refresh()
    _fit_one()
    if mp_active:
        _update_mp_ui_state()


func _refresh() -> void:
    _record_result()
    if win_panel != null:
        if game.winner != 0:
            var human_win := game.winner == Game5D.WHITE
            if mp_active:
                var i_won := game.winner == mp_my_color
                win_label.text = "BẠN THẮNG!" if i_won else "BẠN THUA!"
                human_win = i_won
            elif ai_on:
                win_label.text = "BẠN THẮNG!" if human_win else "AI THẮNG!"
            else:
                win_label.text = "TRẮNG THẮNG!" if human_win else "ĐEN THẮNG!"
            var good := human_win or (not ai_on and not mp_active)
            win_label.add_theme_color_override("font_color", Color(1.0, 0.85, 0.3) if good else Color(1.0, 0.4, 0.4))
            win_panel.visible = not replay_active
            if not _end_focused:
                _end_focused = true
                _focus_loss()
        else:
            win_panel.visible = false
    status.text = msg
    status.visible = msg != ""
    if msg != "":
        _toast_id += 1
        get_tree().create_timer(3.0).timeout.connect(_hide_toast.bind(_toast_id))
    _update_gold_btn()
    _sync_views()
    _redraw()


# ---------------------------------------------------------------- BAN VANG

## Cac bang dau timeline dang den luot nguoi choi (khung vang).
func _gold_boards() -> Array:
    var out: Array = []
    if game.winner != 0 or _ai_locked():
        return out
    for l in game.active_ls():
        var t: int = game.head_t(l)
        if game.color_at_t(t) == game.turn_color:
            out.append(Vector2i(l, t))
    out.sort_custom(func(a, b): return a.x > b.x or (a.x == b.x and a.y < b.y))
    return out


func _update_gold_btn() -> void:
    if gold_btn == null:
        return
    var n := _gold_boards().size()
    gold_btn.text = ("Bàn vàng (%d)" % n) if n > 0 else "Bàn vàng"


## Bam de nhay den ban vang ke tiep (xoay vong).
func _on_gold() -> void:
    var list := _gold_boards()
    if list.is_empty():
        msg = "Không còn bàn vàng nào. Bạn có thể bấm KẾT THÚC LƯỢT." if game.can_submit() else "Hiện chưa có bàn nào để đi."
        _refresh()
        return
    var i := list.find(_gold_key)
    var nxt: Vector2i = list[(i + 1) % list.size()]
    _gold_key = nxt
    _clear_sel()
    msg = "Bàn vàng %d/%d: L%d, T%d" % [list.find(nxt) + 1, list.size(), nxt.x, (nxt.y >> 1) + 1]
    _refresh()
    _fit_rect(_board_rect(nxt.x, nxt.y))


const COST := [3, 2, 1, 1]      # chi phi ve 1 ban theo muc chi tiet (0 = day du ... 3 = chi nen)
const FRAME_BUDGET := 6         # tong chi phi ve toi da moi khung hinh
var _last_sig := Vector3.ZERO


func _bias(d: float, t1: float, t2: float) -> int:
    if d > t2:
        return 2
    if d > t1:
        return 1
    return 0


## Khoang muc chi tiet cho phep cua 1 ban: x = min (min chi tiet nhat), y = max. Co hysteresis de khong nhap nhay.
## Khi dang zoom gan (muc 0) thi moi ban nhin thay deu giu chi tiet day du.
func _lod_range(center: Vector2) -> Vector2i:
    if _lod == 0:
        return Vector2i(0, 0)
    var vs := get_viewport_rect().size
    var d := center.distance_to(camera.position) * camera.zoom.x / (maxf(vs.x, vs.y) * 0.5)
    return Vector2i(mini(_lod + _bias(d, 1.0, 1.6), 3), mini(_lod + _bias(d, 0.8, 1.4), 3))


func _desired_lod(center: Vector2) -> int:
    return _lod_range(center).x


## Moi khung hinh (chi khi camera doi hoac con viec do):
##  - an han cac ban ngoai man hinh (khong ve, khong ton lenh)
##  - ban xa: giam chi tiet ngay (re)
##  - ban gan: tang chi tiet TUNG BAC mot, ban gan tam truoc, trong gioi han ngan sach moi khung
func _process(_delta: float) -> void:
    _poll_ws()
    var sig := Vector3(camera.position.x, camera.position.y, camera.zoom.x)
    if sig == _last_sig and not _stale:
        return
    _last_sig = sig
    var half := get_viewport_rect().size / (2.0 * camera.zoom.x)
    var vis := Rect2(camera.position - half, half * 2.0).grow(BOARD)
    var cand: Array = []
    for v in _views.values():
        var node := v as Node2D
        var rect := Rect2(node.position - Vector2(10, 64), Vector2(BOARD + 20, BOARD + 78))
        if not vis.intersects(rect):
            if node.visible:
                node.visible = false
            continue
        if not node.visible:
            node.visible = true
        var center := node.position + Vector2(BOARD, BOARD) * 0.5
        var rg := _lod_range(center)
        var cur: int = node.get_meta("lod")
        if cur < 0:
            continue                             # chua ve lan dau: se ve ngay khung nay
        var target := cur
        if cur < rg.x:
            target = rg.x                        # chi tiet qua muc cho phep -> giam ngay (re)
        elif cur > rg.y:
            target = cur - 1                     # tang chi tiet tung bac mot
        else:
            continue
        cand.append([center.distance_squared_to(camera.position), node, target])
    var pending := not cand.is_empty()
    if pending:
        cand.sort_custom(func(a, b): return a[0] < b[0])
        var budget := FRAME_BUDGET
        for c in cand:
            var tg: int = c[2]
            var cost: int = COST[tg]
            if budget < cost:
                break
            budget -= cost
            var n2: Node2D = c[1]
            n2.set_meta("want", tg)
            n2.queue_redraw()
            (n2.get_child(0) as Node2D).queue_redraw()
    _stale = pending


# ================================================================ ZOOM / CAMERA

func _zoom_at(f: float, screen_pos: Vector2) -> void:
    var c := get_viewport_rect().size * 0.5
    var old: float = camera.zoom.x
    var nz: float = clampf(old * f, MIN_ZOOM, MAX_ZOOM)
    var w := camera.position + (screen_pos - c) / old
    camera.zoom = Vector2(nz, nz)
    camera.position = w - (screen_pos - c) / nz
    _after_zoom()


func _zoom_center(f: float) -> void:
    _zoom_at(f, get_viewport_rect().size * 0.5)


func _on_zoom_in() -> void:
    _zoom_center(1.3)


func _on_zoom_out() -> void:
    _zoom_center(1.0 / 1.3)


func _on_zoom_slider(v: float) -> void:
    _zoom_center(v / camera.zoom.x)


func _after_zoom() -> void:
    var z: float = camera.zoom.x
    if zoom_panel != null and zoom_panel.visible:
        if zoom_slider != null:
            zoom_slider.set_value_no_signal(z)
        if zoom_label != null:
            zoom_label.text = "Thu phóng: %d%%" % int(round(z * 100.0))
    var lv := 0
    if z < 0.07:
        lv = 3
    elif z < 0.15:
        lv = 2
    elif z < 0.35:
        lv = 1
    if lv != _lod:
        _lod = lv
        _stale = true


func _board_rect(l: int, t: int) -> Rect2:
    return Rect2(_origin(l, t) - Vector2(14, 64), Vector2(BOARD + 28, BOARD + 78))


func _present_rects() -> Array:
    var pt: int = game.present_t()
    var out: Array = []
    for l in game.active_ls():
        if game.head_t(l) == pt:
            out.append(_board_rect(l, pt))
    return out


func _fit_rect(rect: Rect2) -> void:
    var vs := get_viewport_rect().size
    var usable := Vector2(vs.x - 16.0, vs.y - 230.0)
    var z: float = minf(usable.x / rect.size.x, usable.y / rect.size.y)
    z = clampf(z, MIN_ZOOM, MAX_ZOOM)
    camera.zoom = Vector2(z, z)
    camera.position = rect.get_center()
    _after_zoom()


func _fit_one() -> void:
    if has_sel:
        _fit_rect(_board_rect(sel.z, sel.w))
    else:
        var rs := _present_rects()
        _fit_rect(rs[0])


func _fit_present() -> void:
    var rs := _present_rects()
    var rect: Rect2 = rs[0]
    for r in rs:
        rect = rect.merge(r)
    _fit_rect(rect)


func _fit_all() -> void:
    var rect := Rect2()
    var first := true
    for l in game.tl.keys():
        var d: Dictionary = game.tl[l]
        var boards: Array = d["boards"]
        for i in boards.size():
            var r := _board_rect(l, int(d["start"]) + i)
            if first:
                rect = r
                first = false
            else:
                rect = rect.merge(r)
    _fit_rect(rect)


func _center_present() -> void:
    var rs := _present_rects()
    var rect: Rect2 = rs[0]
    for r in rs:
        rect = rect.merge(r)
    camera.position = rect.get_center()


# ================================================================ INPUT

func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        var st := event as InputEventScreenTouch
        if st.pressed:
            if st.index == 0:
                _touches.clear()
            _touches[st.index] = st.position
        else:
            _touches.erase(st.index)
        if _touches.size() == 2:
            _dragging = true
            _read_pinch(false)
        return
    if event is InputEventScreenDrag:
        var sd := event as InputEventScreenDrag
        _touches[sd.index] = sd.position
        if _touches.size() == 2:
            _read_pinch(true)
        return
    if event is InputEventMagnifyGesture:
        var mg := event as InputEventMagnifyGesture
        _zoom_at(mg.factor, mg.position)
        return
    if event is InputEventMouseButton:
        var mb := event as InputEventMouseButton
        if mb.button_index == MOUSE_BUTTON_WHEEL_UP and mb.pressed:
            _zoom_at(1.1, mb.position)
        elif mb.button_index == MOUSE_BUTTON_WHEEL_DOWN and mb.pressed:
            _zoom_at(1.0 / 1.1, mb.position)
        elif mb.button_index == MOUSE_BUTTON_LEFT:
            if mb.pressed:
                _pressed = true
                _dragging = false
                _press_pos = mb.position
            else:
                if _pressed and not _dragging and _touches.size() < 2:
                    _click(get_global_mouse_position())
                _pressed = false
                _dragging = false
    elif event is InputEventMouseMotion and _pressed:
        if _touches.size() >= 2:
            return
        var mm := event as InputEventMouseMotion
        if not _dragging and mm.position.distance_to(_press_pos) > 10.0:
            _dragging = true
        if _dragging:
            camera.position -= mm.relative / camera.zoom.x


func _read_pinch(apply: bool) -> void:
    var pts: Array = _touches.values()
    var p0: Vector2 = pts[0]
    var p1: Vector2 = pts[1]
    var d := p0.distance_to(p1)
    var mid := (p0 + p1) * 0.5
    if apply and _pinch_dist > 1.0 and d > 1.0:
        _zoom_at(d / _pinch_dist, mid)
        camera.position -= (mid - _pinch_mid) / camera.zoom.x
    _pinch_dist = d
    _pinch_mid = mid


func _click(wp: Vector2) -> void:
    if _ai_locked():
        return
    var cell: Variant = _cell_at(wp)
    if cell == null:
        _clear_sel()
        _redraw()
        return
    var c: Vector4i = cell
    if has_sel and targets.has(c):
        _do_move(c)
        return
    if game.can_move_from(c):
        sel = c
        has_sel = true
        targets = game.moves_for(c)
    else:
        _clear_sel()
    _redraw()


func _do_move(dst: Vector4i) -> void:
    if mp_active and game.turn_color != mp_my_color:
        return
    history.append(game.snapshot())
    var src := sel
    game.apply_move(src, dst)
    _play_move()
    last_moves = []
    msg = ""
    _clear_sel()
    _refresh()
    if mp_active and mp_connected:
        _ws_send({
            "type": "move",
            "src": [src.x, src.y, src.z, src.w],
            "dst": [dst.x, dst.y, dst.z, dst.w]
        })
        msg = "Đã đi. Chờ đối thủ..."
        _toast(msg)


func _clear_sel() -> void:
    has_sel = false
    targets = []


func _origin(l: int, t: int) -> Vector2:
    return Vector2(t * STEP, -l * STEP)


func _cell_rect(c: Vector4i) -> Rect2:
    return Rect2(_origin(c.z, c.w) + Vector2(c.x * CELL, (N - 1 - c.y) * CELL), Vector2(CELL, CELL))


func _cell_at(wp: Vector2) -> Variant:
    var t := floori(wp.x / STEP)
    var row := floori(wp.y / STEP)
    var l := -row
    var lx := wp.x - t * STEP
    var ly := wp.y - row * STEP
    if lx < 0.0 or lx >= BOARD or ly < 0.0 or ly >= BOARD:
        return null
    if game.board_at(l, t).is_empty():
        return null
    return Vector4i(int(lx / CELL), N - 1 - int(ly / CELL), l, t)


# ================================================================ VE

func _redraw() -> void:
    queue_redraw()
    overlay.queue_redraw()


func _redraw_views() -> void:
    for v in _views.values():
        (v as Node2D).queue_redraw()


## Dong bo node ban co voi trang thai van. Ban co cu khong doi nen chi ve 1 lan.
func _sync_views() -> void:
    var seen: Dictionary = {}
    for l in game.tl.keys():
        var d: Dictionary = game.tl[l]
        var boards: Array = d["boards"]
        var act: bool = game.is_active(l)
        var head: int = game.head_t(l)
        for i in boards.size():
            var t: int = int(d["start"]) + i
            var key := Vector2i(l, t)
            seen[key] = true
            var nb: PackedInt32Array = boards[i]
            var mine: bool = act and t == head and game.winner == 0 and game.color_at_t(t) == game.turn_color
            var sig := (1 if act else 0) | (2 if t == head else 0) | (4 if mine else 0)
            var view: Node2D = _views.get(key)
            if view == null:
                view = Node2D.new()
                view.position = _origin(l, t)
                view.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
                view.set_meta("lod", -1)
                view.set_meta("want", _desired_lod(view.position + Vector2(BOARD, BOARD) * 0.5))
                view.set_meta("l", l)
                view.set_meta("t", t)
                view.set_meta("board", nb)
                view.set_meta("sig", sig)
                view.draw.connect(_draw_view.bind(view))
                var fr := Node2D.new()
                fr.show_behind_parent = true
                fr.draw.connect(_draw_frame.bind(view))
                view.add_child(fr)
                add_child(view)
                _views[key] = view
            else:
                var ob: PackedInt32Array = view.get_meta("board")
                if ob != nb:
                    view.set_meta("board", nb)
                    view.set_meta("sig", sig)
                    view.queue_redraw()
                    (view.get_child(0) as Node2D).queue_redraw()
                elif int(view.get_meta("sig")) != sig:
                    view.set_meta("sig", sig)
                    (view.get_child(0) as Node2D).queue_redraw()
    for key in _views.keys():
        if not seen.has(key):
            (_views[key] as Node2D).queue_free()
            _views.erase(key)
    _stale = true


func _draw() -> void:
    var keys: Array = game.tl.keys()
    keys.sort()
    var minl: int = keys[0]
    var maxl: int = keys[keys.size() - 1]
    var pt: int = game.present_t()

    # vung present
    draw_rect(Rect2(pt * STEP - GAP * 0.5, -maxl * STEP - GAP * 0.5, BOARD + GAP, (maxl - minl) * STEP + BOARD + GAP), Color(0.3, 0.8, 1.0, 0.12))

    # duong noi nhanh timeline
    for l in keys:
        if l == 0:
            continue
        var d: Dictionary = game.tl[l]
        var s: int = d["start"]
        var pl: int = d["parent"]
        draw_line(_origin(pl, s - 1) + Vector2(BOARD, BOARD * 0.5), _origin(l, s) + Vector2(0, BOARD * 0.5), Color(1, 1, 1, 0.3), 6.0)


func _draw_overlay() -> void:
    if end_mark.x >= 0:
        var er := _cell_rect(end_mark)
        overlay.draw_rect(er, Color(1, 0.1, 0.1, 0.5))
        overlay.draw_rect(er, Color(1, 0.2, 0.2), false, 6.0)
        overlay.draw_arc(er.get_center(), CELL * 0.85, 0.0, TAU, 32, Color(1, 0.25, 0.25, 0.95), 5.0)
    if replay_active:
        var z: float = camera.zoom.x
        var cur := replay_from.lerp(replay_to, replay_t)
        var wdt := maxf(10.0, 6.0 / z)
        var ring := maxf(CELL * 0.75, 14.0 / z)
        overlay.draw_line(replay_from, cur, Color(1, 0.25, 0.25, 0.9), wdt)
        overlay.draw_arc(replay_from, ring, 0.0, TAU, 32, Color(1, 0.85, 0.3), wdt * 0.6)
        overlay.draw_arc(replay_to, ring, 0.0, TAU, 32, Color(1, 0.2, 0.2), wdt * 0.6)
        if z >= 0.35:
            _draw_piece(overlay, cur - Vector2(CELL, CELL) * 0.5, replay_piece, 0)
        else:
            var rr := maxf(CELL * 0.5, 16.0 / z)
            overlay.draw_circle(cur, rr, Color(1, 0.25, 0.25))
            overlay.draw_circle(cur, rr * 0.7, PIECE_W if replay_piece > 0 else PIECE_B)
    # nuoc di cua AI (o cam)
    for lc in last_moves:
        overlay.draw_rect(_cell_rect(lc), Color(1.0, 0.55, 0.1), false, 5.0)
    if not has_sel:
        return
    var sc := _cell_rect(sel).get_center()
    for q in targets:
        if q.z != sel.z or q.w != sel.w:
            overlay.draw_line(sc, _cell_rect(q).get_center(), Color(1, 1, 1, 0.16), 3.0)
    for q in targets:
        var r2 := _cell_rect(q)
        if game.piece_at(q) != 0:
            overlay.draw_rect(r2, Color(1, 0.15, 0.15, 0.45))
            overlay.draw_rect(r2, Color(1, 0.25, 0.25), false, 4.0)
        else:
            overlay.draw_circle(r2.get_center(), CELL * 0.22, Color(0, 0, 0, 0.35))
            overlay.draw_circle(r2.get_center(), CELL * 0.17, Color(0.3, 1.0, 0.45, 0.95))
    overlay.draw_rect(_cell_rect(sel), Color(1, 0.9, 0.2), false, 5.0)


func _build_board_tex() -> void:
    var img := Image.create(8, 8, false, Image.FORMAT_RGBA8)
    for r in 8:
        for x in 8:
            var y := 7 - r
            img.set_pixel(x, r, DARK if (x + y) % 2 == 0 else LIGHT)
    _board_tex = ImageTexture.create_from_image(img)


func _draw_view(view: Node2D) -> void:
    var board: PackedInt32Array = view.get_meta("board")
    var sig: int = view.get_meta("sig")
    var lod: int = view.get_meta("want")
    view.set_meta("lod", lod)
    var act := (sig & 1) != 0
    var tint := Color(1, 1, 1) if act else Color(0.45, 0.45, 0.45)
    view.draw_texture_rect(_board_tex, Rect2(Vector2.ZERO, Vector2(BOARD, BOARD)), false, tint)
    if lod >= 3:
        return                                   # zoom rat xa: chi ve nen ban
    for y in N:
        for x in N:
            var v: int = board[y * N + x]
            if v != 0:
                _draw_piece(view, Vector2(x * CELL, (N - 1 - y) * CELL), v, lod)


## Khung + nhan nam o node con (ve phia sau ban co), rat nhe: doi trang thai chi ve lai phan nay.
func _draw_frame(view: Node2D) -> void:
    var fr: Node2D = view.get_child(0)
    var l: int = view.get_meta("l")
    var t: int = view.get_meta("t")
    var sig: int = view.get_meta("sig")
    var act := (sig & 1) != 0
    var is_head := (sig & 2) != 0
    var mine := (sig & 4) != 0
    var frame := FRAME_PAST
    if mine:
        frame = FRAME_MINE
    elif act and is_head:
        frame = FRAME_HEAD
    fr.draw_rect(Rect2(Vector2(-10, -10), Vector2(BOARD + 20, BOARD + 20)), frame)
    if int(view.get_meta("want")) >= 3:
        return
    var tag := "L%d  T%d%s" % [l, (t >> 1) + 1, "w" if t % 2 == 0 else "b"]
    if not act:
        tag += "  (không hoạt động)"
    var tc := Color(1, 1, 1) if act else Color(0.55, 0.55, 0.55)
    if mine:
        tc = Color(1.0, 0.85, 0.3)
    fr.draw_string(ThemeDB.fallback_font, Vector2(0, -20), tag, HORIZONTAL_ALIGNMENT_LEFT, -1, 34, tc)


func _draw_piece(cv: CanvasItem, pos: Vector2, v: int, lod: int) -> void:
    var white := v > 0
    var fill := PIECE_W if white else PIECE_B
    var edge := EDGE_W if white else EDGE_B
    if lod == 2:                                # xa: 1 o vuong
        cv.draw_rect(Rect2(pos + Vector2(CELL * 0.2, CELL * 0.2), Vector2(CELL * 0.6, CELL * 0.6)), fill)
        return
    if lod == 1:                                # vua: hinh tron co vien
        var c := pos + Vector2(CELL, CELL) * 0.5
        cv.draw_circle(c, CELL * 0.40, edge)
        cv.draw_circle(c, CELL * 0.33, fill)
        return
    var sh: Dictionary = _shapes[absi(v)]        # gan: quan vector day du
    var sc := CELL / 100.0
    var mo: Mesh = sh["m_outer"]
    var mf: Mesh = sh["m_fill"]
    if mo != null and mf != null:
        var ax := Vector2(sc, 0.0)
        var ay := Vector2(0.0, sc)
        cv.draw_mesh(mo, null, Transform2D(ax, ay, pos + Vector2(3.0, 3.0)), SHADOW)
        cv.draw_mesh(mo, null, Transform2D(ax, ay, pos), edge)
        cv.draw_mesh(mf, null, Transform2D(ax, ay, pos), fill)
        cv.draw_set_transform(pos, 0.0, Vector2(sc, sc))
    else:
        var parts: Array = sh["parts"]
        var outer: Array = sh["outer"]
        cv.draw_set_transform(pos + Vector2(3.0, 3.0), 0.0, Vector2(sc, sc))
        for p in outer:
            cv.draw_colored_polygon(p, SHADOW)
        cv.draw_set_transform(pos, 0.0, Vector2(sc, sc))
        for p in outer:
            cv.draw_colored_polygon(p, edge)
        for p in parts:
            cv.draw_colored_polygon(p, fill)
    var det := DETAIL_W if white else DETAIL_B
    for ln in sh["lines"]:
        cv.draw_polyline(ln, det, 2.4)
    for dt in sh["dots"]:
        cv.draw_circle(Vector2(dt.x, dt.y), dt.z, det)
    cv.draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)


# ================================================================ AI

func _ai_locked() -> bool:
    if mp_active:
        return game.turn_color != mp_my_color or not mp_connected
    return ai_on and (_ai_busy or game.turn_color == Game5D.BLACK)


func _on_ai_toggled(on: bool) -> void:
    ai_on = on
    if on:
        msg = "AI cầm quân Đen đã BẬT."
        _refresh()
        _maybe_ai()
    else:
        _ai_token += 1
        _ai_busy = false
        ai.cancel()
        msg = "Chế độ 2 người (AI tắt)."
        _refresh()
    _update_ai_label()


func _on_ai_reset() -> void:
    ai.reset()
    msg = "Đã xóa trí nhớ AI, AI quay về cấp 1."
    _update_ai_label()
    _refresh()


func _update_ai_label() -> void:
    if ai_label == null:
        return
    ai_label.text = "AI cấp %d (%d ván, thắng %d). Giá trị quân AI đã học: Tốt %.1f, Mã %.1f, Tượng %.1f, Xe %.1f, Hậu %.1f" % [ai.level(), ai.games, ai.wins, ai.w[0], ai.w[1], ai.w[2], ai.w[3], ai.w[4]]


## Ghi nhan ket qua van dau cho AI hoc (chi 1 lan / van).
func _record_result() -> void:
    if _game_recorded or game.winner == 0:
        return
    _game_recorded = true
    if ai_on and ai.trajectory.size() > 0:
        var before: int = ai.level()
        ai.learn(1 if game.winner == Game5D.BLACK else -1)
        msg = "AI đã học từ ván này."
        if ai.level() > before:
            msg += " AI vừa lên cấp %d!" % ai.level()
    ai.trajectory.clear()
    _update_ai_label()


func _maybe_ai() -> void:
    if not ai_on or _ai_busy or game.winner != 0 or game.turn_color != Game5D.BLACK:
        return
    _run_ai()


func _run_ai() -> void:
    _ai_busy = true
    var token := _ai_token
    _clear_sel()
    msg = "AI đang suy nghĩ..."
    _refresh()
    await get_tree().create_timer(0.3).timeout
    if token != _ai_token:
        return
    var clone: Game5D = game.clone()
    var plan: Array = await ai.plan_turn(clone, get_tree())
    if token != _ai_token:
        return
    if plan.is_empty():
        game.winner = Game5D.WHITE
        msg = "AI không tìm được nước đi hợp lệ nên đầu hàng."
        _ai_busy = false
        _refresh()
        return
    last_moves = []
    for mv in plan:
        game.apply_move(mv[0], mv[1])
        _play_move()
        last_moves.append(mv[0])
        last_moves.append(mv[1])
        _refresh()
        await get_tree().create_timer(0.5).timeout
        if token != _ai_token:
            return
        if game.winner != 0:
            break
    if game.winner == 0:
        var err := game.submit()
        if err == "":
            ai.record(game)
            msg = "AI đã đi xong (ô viền cam). Đến lượt bạn."
            _center_present()
        else:
            msg = "AI lỗi: " + err
    _ai_busy = false
    _refresh()


# ================================================================ MULTIPLAYER (WebSocket Relay)

func _build_mp_ui() -> void:
    var layer := ui_layer
    if layer == null:
        return
    mp_panel = _make_panel(layer)
    mp_panel.offset_top = -420
    var v := VBoxContainer.new()
    v.add_theme_constant_override("separation", 8)
    mp_panel.add_child(v)

    var title := Label.new()
    title.text = "MULTIPLAYER ONLINE"
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title.add_theme_font_size_override("font_size", 26)
    v.add_child(title)

    name_edit = LineEdit.new()
    name_edit.placeholder_text = "Tên của bạn"
    name_edit.text = mp_name
    name_edit.add_theme_font_size_override("font_size", UI_FONT)
    name_edit.custom_minimum_size = Vector2(0, 56)
    v.add_child(name_edit)

    room_edit = LineEdit.new()
    room_edit.placeholder_text = "Mã phòng (để trống nếu tạo mới)"
    room_edit.add_theme_font_size_override("font_size", UI_FONT)
    room_edit.custom_minimum_size = Vector2(0, 56)
    v.add_child(room_edit)

    var row := HBoxContainer.new()
    row.add_theme_constant_override("separation", 8)
    v.add_child(row)
    create_btn = _btn(row, "Tạo phòng", _on_mp_create)
    join_btn = _btn(row, "Vào phòng", _on_mp_join)

    leave_btn = _btn(v, "Rời phòng / Hủy", _on_mp_leave)
    leave_btn.visible = false

    mp_status = Label.new()
    mp_status.text = "Chưa kết nối.\nServer: " + RELAY_URL
    mp_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    mp_status.add_theme_font_size_override("font_size", 18)
    mp_status.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    v.add_child(mp_status)

    var closeb := _btn(v, "Đóng", _toggle_mp_panel)
    # Thêm nút Multiplayer vào menu chính
    if menu_panel:
        var mv = menu_panel.get_child(0)
        if mv is VBoxContainer:
            var mb := Button.new()
            mb.text = "Multiplayer Online"
            mb.custom_minimum_size = Vector2(0, 72)
            mb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
            mb.add_theme_font_size_override("font_size", UI_FONT)
            mb.pressed.connect(_toggle_mp_panel)
            mv.add_child(mb)
            # đưa nút lên gần đầu
            mv.move_child(mb, 1)


func _toggle_mp_panel() -> void:
    if mp_panel == null:
        return
    menu_panel.visible = false
    zoom_panel.visible = false
    mp_panel.visible = not mp_panel.visible
    if mp_panel.visible:
        name_edit.text = mp_name
        if not mp_connected:
            mp_status.text = "Chưa kết nối.\nServer: " + RELAY_URL
        else:
            mp_status.text = "Đang trong phòng %s" % mp_room


func _ws_send(obj: Dictionary) -> void:
    if ws.get_ready_state() != WebSocketPeer.STATE_OPEN:
        return
    ws.send_text(JSON.stringify(obj))


func _poll_ws() -> void:
    ws.poll()
    var st := ws.get_ready_state()
    if st == WebSocketPeer.STATE_OPEN:
        while ws.get_available_packet_count() > 0:
            var pkt := ws.get_packet().get_string_from_utf8()
            var data = JSON.parse_string(pkt)
            if data is Dictionary:
                _on_ws_msg(data)
    elif st == WebSocketPeer.STATE_CLOSED and mp_connected:
        mp_connected = false
        mp_active = false
        msg = "Mất kết nối server."
        _toast(msg)
        _update_mp_ui_state()


func _connect_ws() -> bool:
    if ws.get_ready_state() == WebSocketPeer.STATE_OPEN:
        return true
    var err := ws.connect_to_url(RELAY_URL)
    if err != OK:
        mp_status.text = "Không kết nối được server!\nKiểm tra RELAY_URL hoặc server đang chạy."
        return false
    # Đợi kết nối (tối đa ~3s)
    var t0 := Time.get_ticks_msec()
    while ws.get_ready_state() == WebSocketPeer.STATE_CONNECTING:
        ws.poll()
        if Time.get_ticks_msec() - t0 > 3000:
            mp_status.text = "Timeout kết nối server."
            return false
        OS.delay_msec(30)
    if ws.get_ready_state() != WebSocketPeer.STATE_OPEN:
        mp_status.text = "Kết nối thất bại."
        return false
    return true


func _on_mp_create() -> void:
    mp_name = name_edit.text.strip_edges()
    if mp_name.is_empty():
        mp_name = "Host"
    if not _connect_ws():
        return
    _ws_send({"type": "create", "name": mp_name})
    mp_status.text = "Đang tạo phòng..."
    create_btn.disabled = true
    join_btn.disabled = true


func _on_mp_join() -> void:
    mp_name = name_edit.text.strip_edges()
    if mp_name.is_empty():
        mp_name = "Guest"
    var code := room_edit.text.strip_edges().to_upper()
    if code.is_empty():
        mp_status.text = "Nhập mã phòng để vào!"
        return
    if not _connect_ws():
        return
    _ws_send({"type": "join", "room": code, "name": mp_name})
    mp_status.text = "Đang vào phòng %s..." % code
    create_btn.disabled = true
    join_btn.disabled = true


func _on_mp_leave() -> void:
    if ws.get_ready_state() == WebSocketPeer.STATE_OPEN:
        ws.close()
    mp_connected = false
    mp_active = false
    mp_room = ""
    mp_player_id = 0
    mp_opponent = ""
    mp_my_color = 0
    ai_on = true
    msg = "Đã rời phòng."
    _toast(msg)
    _update_mp_ui_state()
    _start_new()


func _update_mp_ui_state() -> void:
    if mp_status == null:
        return
    create_btn.disabled = mp_connected
    join_btn.disabled = mp_connected
    leave_btn.visible = mp_connected or mp_room != ""
    room_edit.editable = not mp_connected
    name_edit.editable = not mp_connected
    if mp_connected and mp_active:
        mp_status.text = "Phòng %s\nBạn: %s (%s)\nĐối thủ: %s\n%s" % [
            mp_room, mp_name,
            "Trắng" if mp_my_color == Game5D.WHITE else "Đen",
            mp_opponent,
            "Đến lượt BẠN" if game.turn_color == mp_my_color else "Chờ đối thủ..."
        ]
    elif mp_connected:
        mp_status.text = "Phòng %s\nĐang chờ đối thủ...\nChia sẻ mã: %s" % [mp_room, mp_room]
    else:
        mp_status.text = "Chưa kết nối.\nServer: " + RELAY_URL


func _on_ws_msg(data: Dictionary) -> void:
    var t: String = str(data.get("type", ""))
    match t:
        "created":
            mp_room = str(data.get("room", ""))
            mp_player_id = int(data.get("playerId", 1))
            mp_my_color = Game5D.WHITE
            mp_connected = true
            mp_active = false
            ai_on = false
            room_edit.text = mp_room
            msg = "Đã tạo phòng %s. Chờ đối thủ..." % mp_room
            _toast(msg)
            _update_mp_ui_state()
        "joined":
            mp_room = str(data.get("room", ""))
            mp_player_id = int(data.get("playerId", 2))
            mp_my_color = Game5D.BLACK
            mp_opponent = str(data.get("opponent", "Host"))
            mp_connected = true
            mp_active = false
            ai_on = false
            msg = "Đã vào phòng %s. Chờ bắt đầu..." % mp_room
            _toast(msg)
            _update_mp_ui_state()
        "opponent_joined":
            mp_opponent = str(data.get("name", "Guest"))
            msg = "%s đã vào phòng!" % mp_opponent
            _toast(msg)
            _update_mp_ui_state()
        "start":
            mp_active = true
            mp_connected = true
            ai_on = false
            _ai_token += 1
            _ai_busy = false
            game.new_game()
            history.clear()
            last_moves.clear()
            has_sel = false
            targets = []
            end_mark = Vector4i(-1, -1, -1, -1)
            _game_recorded = false
            _end_token += 1
            if mp_player_id == 1:
                mp_my_color = Game5D.WHITE
                mp_opponent = str(data.get("guestName", "Guest"))
            else:
                mp_my_color = Game5D.BLACK
                mp_opponent = str(data.get("hostName", "Host"))
            msg = "Bắt đầu! Bạn cầm %s. Đối thủ: %s" % ["TRẮNG" if mp_my_color == Game5D.WHITE else "ĐEN", mp_opponent]
            _toast(msg)
            _update_mp_ui_state()
            _refresh()
            _center_present()
            mp_panel.visible = false
        "move":
            if not mp_active:
                return
            var src_a: Array = data.get("src", [])
            var dst_a: Array = data.get("dst", [])
            if src_a.size() < 4 or dst_a.size() < 4:
                return
            var src := Vector4i(int(src_a[0]), int(src_a[1]), int(src_a[2]), int(src_a[3]))
            var dst := Vector4i(int(dst_a[0]), int(dst_a[1]), int(dst_a[2]), int(dst_a[3]))
            # Chỉ áp dụng nước của đối thủ
            if game.turn_color == mp_my_color:
                return
            history.append(game.snapshot())
            game.apply_move(src, dst)
            _play_move()
            last_moves = [src, dst]
            msg = "Đối thủ đã đi. Đến lượt bạn!"
            _toast(msg)
            _clear_sel()
            _refresh()
            _update_mp_ui_state()
        "resign":
            if mp_active:
                game.winner = mp_my_color
                msg = "Đối thủ đầu hàng! Bạn thắng."
                _toast(msg)
                _refresh()
        "opponent_left":
            msg = "Đối thủ đã rời phòng."
            _toast(msg)
            mp_active = false
            _update_mp_ui_state()
        "error":
            msg = str(data.get("message", "Lỗi"))
            _toast(msg)
            mp_status.text = msg
            create_btn.disabled = false
            join_btn.disabled = false


func _toast(text: String) -> void:
    msg = text
    if status:
        status.text = text
        status.visible = true
        _toast_id += 1
        get_tree().create_timer(4.0).timeout.connect(_hide_toast.bind(_toast_id))
