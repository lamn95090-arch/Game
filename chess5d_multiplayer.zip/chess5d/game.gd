extends RefCounted
## Logic co vua 5D (rut gon).
## Toa do: Vector4i(x, y, l, t)
##   x,y = o tren ban (y=0 la hang cua Trang), l = timeline, t = nua luot (chan = Trang di, le = Den di)
## Quan co di chuyen tren 4 truc (x, y, l, t); truc t tinh theo luot cua cung mau (2 nua luot).

const N := 8
const RIGHTS := 64   # chi so o luu quyen nhap thanh trong moi ban
const WHITE := 1
const BLACK := -1
const PAWN := 1
const KNIGHT := 2
const BISHOP := 3
const ROOK := 4
const QUEEN := 5
const KING := 6

var tl: Dictionary = {}   # l -> {"start": int, "boards": Array[PackedInt32Array], "parent": int}
var n_white := 0          # so timeline Trang da tao (l duong)
var n_black := 0          # so timeline Den da tao (l am)
var turn_color := WHITE
var winner := 0
var end_cell := Vector4i(-1, -1, -1, -1)   # o co Vua bi an (neu van ket thuc bang an Vua)
var end_src := Vector4i(-1, -1, -1, -1)    # o xuat phat cua quan an Vua
var end_piece := 0                         # quan an Vua (dau = mau)
var strict_check := true  # bat: cam de Vua bi chieu khi ket thuc luot

var _log: Array = []
var _dirs_all: Array = []
var _dirs_rook: Array = []
var _dirs_bishop: Array = []


func _init() -> void:
    for a in range(-1, 2):
        for b in range(-1, 2):
            for c in range(-1, 2):
                for d in range(-1, 2):
                    var nz := int(a != 0) + int(b != 0) + int(c != 0) + int(d != 0)
                    if nz == 0:
                        continue
                    var v := Vector4i(a, b, c, d)
                    _dirs_all.append(v)
                    if nz == 1:
                        _dirs_rook.append(v)
                    elif nz == 2:
                        _dirs_bishop.append(v)
    new_game()


func new_game() -> void:
    tl = {0: {"start": 0, "boards": [_initial_board()], "parent": 0}}
    n_white = 0
    n_black = 0
    turn_color = WHITE
    winner = 0
    end_cell = Vector4i(-1, -1, -1, -1)
    end_src = Vector4i(-1, -1, -1, -1)
    end_piece = 0


func _initial_board() -> PackedInt32Array:
    var b := PackedInt32Array()
    b.resize(N * N + 1)
    b[RIGHTS] = 15
    var back: Array = [ROOK, KNIGHT, BISHOP, QUEEN, KING, BISHOP, KNIGHT, ROOK]
    for x in N:
        b[x] = back[x]
        b[N + x] = PAWN
        b[6 * N + x] = -PAWN
        b[7 * N + x] = -int(back[x])
    return b


# ---------------------------------------------------------------- truy van

func idx(x: int, y: int) -> int:
    return y * N + x


func color_at_t(t: int) -> int:
    return WHITE if t % 2 == 0 else BLACK


func head_t(l: int) -> int:
    var d: Dictionary = tl[l]
    var boards: Array = d["boards"]
    return int(d["start"]) + boards.size() - 1


func board_at(l: int, t: int) -> PackedInt32Array:
    if not tl.has(l):
        return PackedInt32Array()
    var d: Dictionary = tl[l]
    var boards: Array = d["boards"]
    var i: int = t - int(d["start"])
    if i < 0 or i >= boards.size():
        return PackedInt32Array()
    return boards[i]


func piece_at(p: Vector4i) -> int:
    var b := board_at(p.z, p.w)
    if b.is_empty():
        return 0
    return b[idx(p.x, p.y)]


func is_active(l: int) -> bool:
    var r := mini(n_white, n_black) + 1
    return tl.has(l) and l >= -r and l <= r


func active_ls() -> Array:
    var out: Array = []
    for l in tl.keys():
        if is_active(l):
            out.append(l)
    out.sort()
    return out


## "Present" = nua luot som nhat trong cac dau timeline dang hoat dong.
func present_t() -> int:
    var m := 1 << 30
    for l in active_ls():
        m = mini(m, head_t(l))
    return m


func can_submit() -> bool:
    return winner == 0 and color_at_t(present_t()) != turn_color


func can_move_from(p: Vector4i) -> bool:
    if winner != 0 or not is_active(p.z):
        return false
    if p.w != head_t(p.z) or color_at_t(p.w) != turn_color:
        return false
    var v := piece_at(p)
    return v != 0 and signi(v) == turn_color


# ---------------------------------------------------------------- sinh nuoc di

static func off(p: Vector4i, d: Vector4i, k: int = 1) -> Vector4i:
    return Vector4i(p.x + d.x * k, p.y + d.y * k, p.z + d.z * k, p.w + 2 * d.w * k)


## -1 = khong ton tai / ngoai ban / timeline khong hoat dong, 0 = trong,
## 1 = quan dich bat duoc, 2 = quan minh (hoac vua o qua khu: khong bat duoc)
func _look(q: Vector4i, c: int) -> int:
    if q.x < 0 or q.x >= N or q.y < 0 or q.y >= N:
        return -1
    if not is_active(q.z):
        return -1
    var b := board_at(q.z, q.w)
    if b.is_empty():
        return -1
    var v: int = b[idx(q.x, q.y)]
    if v == 0:
        return 0
    if signi(v) == c:
        return 2
    if absi(v) == KING and q.w != head_t(q.z):
        return 2
    return 1


func moves_for(p: Vector4i) -> Array:
    var out: Array = []
    var piece := piece_at(p)
    if piece == 0:
        return out
    var c := signi(piece)
    match absi(piece):
        PAWN:
            _pawn_moves(p, c, out)
        KNIGHT:
            _knight_moves(p, c, out)
        BISHOP:
            _slide(p, c, _dirs_bishop, out)
        ROOK:
            _slide(p, c, _dirs_rook, out)
        QUEEN:
            _slide(p, c, _dirs_all, out)
        KING:
            _step(p, c, _dirs_all, out)
            _castle_moves(p, c, out)
    return out


## O (x, y) co bi quan mau `by` tan cong ngay tren ban nay khong (chi tinh nuoc di tren cung 1 ban).
func _spatial_attacked(b: PackedInt32Array, x: int, y: int, by: int) -> bool:
    for kd in [[1, 2], [2, 1], [-1, 2], [-2, 1], [1, -2], [2, -1], [-1, -2], [-2, -1]]:
        var nx: int = x + int(kd[0])
        var ny: int = y + int(kd[1])
        if nx >= 0 and nx < N and ny >= 0 and ny < N and b[idx(nx, ny)] == KNIGHT * by:
            return true
    for dy in range(-1, 2):
        for dx in range(-1, 2):
            if dx == 0 and dy == 0:
                continue
            var kx := x + dx
            var ky := y + dy
            if kx >= 0 and kx < N and ky >= 0 and ky < N and b[idx(kx, ky)] == KING * by:
                return true
    for pdx in [-1, 1]:
        var px: int = x + int(pdx)
        var py: int = y - by
        if px >= 0 and px < N and py >= 0 and py < N and b[idx(px, py)] == PAWN * by:
            return true
    for dy in range(-1, 2):
        for dx in range(-1, 2):
            if dx == 0 and dy == 0:
                continue
            var sx := x + dx
            var sy := y + dy
            while sx >= 0 and sx < N and sy >= 0 and sy < N:
                var v := b[idx(sx, sy)]
                if v != 0:
                    if signi(v) == by:
                        var a := absi(v)
                        var diag := dx != 0 and dy != 0
                        if a == QUEEN or (diag and a == BISHOP) or (not diag and a == ROOK):
                            return true
                    break
                sx += dx
                sy += dy
    return false


## Nhap thanh: Vua + Xe chua di, cac o giua trong, Vua khong dang bi chieu va khong di qua/den o bi tan cong (tren cung ban).
func _castle_moves(p: Vector4i, c: int, out: Array) -> void:
    var home := 0 if c == WHITE else N - 1
    if p.x != 4 or p.y != home:
        return
    var b := board_at(p.z, p.w)
    if b.size() <= RIGHTS or b[idx(4, home)] != KING * c:
        return
    var ks := 1 if c == WHITE else 4
    var qs := 2 if c == WHITE else 8
    var r := b[RIGHTS]
    if (r & (ks | qs)) == 0:
        return
    if _spatial_attacked(b, 4, home, -c):
        return
    var rook := ROOK * c
    if (r & ks) != 0 and b[idx(7, home)] == rook and b[idx(5, home)] == 0 and b[idx(6, home)] == 0:
        if not _spatial_attacked(b, 5, home, -c) and not _spatial_attacked(b, 6, home, -c):
            out.append(Vector4i(6, home, p.z, p.w))
    if (r & qs) != 0 and b[idx(0, home)] == rook and b[idx(1, home)] == 0 and b[idx(2, home)] == 0 and b[idx(3, home)] == 0:
        if not _spatial_attacked(b, 3, home, -c) and not _spatial_attacked(b, 2, home, -c):
            out.append(Vector4i(2, home, p.z, p.w))


## Cap nhat quyen nhap thanh tren ban `b` sau khi `piece` roi o (sx, sy) va (neu co) an quan `cap` tai (dx, dy).
func _rights_after(b: PackedInt32Array, piece: int, sx: int, sy: int, cap: int, dx: int, dy: int) -> void:
    var r := b[RIGHTS]
    var c := signi(piece)
    var a := absi(piece)
    var home := 0 if c == WHITE else N - 1
    if a == KING:
        r &= ~(3 if c == WHITE else 12)
    elif a == ROOK and sy == home:
        if sx == 7:
            r &= ~(1 if c == WHITE else 4)
        elif sx == 0:
            r &= ~(2 if c == WHITE else 8)
    if absi(cap) == ROOK:
        var oc := signi(cap)
        var ohome := 0 if oc == WHITE else N - 1
        if dy == ohome:
            if dx == 7:
                r &= ~(1 if oc == WHITE else 4)
            elif dx == 0:
                r &= ~(2 if oc == WHITE else 8)
    b[RIGHTS] = r


func _slide(p: Vector4i, c: int, dirs: Array, out: Array) -> void:
    for d in dirs:
        var q := p
        while true:
            q = off(q, d)
            var s := _look(q, c)
            if s == -1 or s == 2:
                break
            out.append(q)
            if s == 1:
                break


func _step(p: Vector4i, c: int, dirs: Array, out: Array) -> void:
    for d in dirs:
        var q := off(p, d)
        var s := _look(q, c)
        if s == 0 or s == 1:
            out.append(q)


func _knight_moves(p: Vector4i, c: int, out: Array) -> void:
    for a in 4:
        for b in 4:
            if a == b:
                continue
            for sa in [-2, 2]:
                for sb in [-1, 1]:
                    var v := [0, 0, 0, 0]
                    v[a] = sa
                    v[b] = sb
                    var q := off(p, Vector4i(v[0], v[1], v[2], v[3]))
                    var s := _look(q, c)
                    if s == 0 or s == 1:
                        out.append(q)


func _pawn_moves(p: Vector4i, c: int, out: Array) -> void:
    var fy := Vector4i(0, c, 0, 0)   # tien theo y
    var fl := Vector4i(0, 0, c, 0)   # tien theo timeline (Trang +l, Den -l)
    var q := off(p, fy)
    if _look(q, c) == 0:
        out.append(q)
        var start_rank := 1 if c == WHITE else N - 2
        if p.y == start_rank:
            var q2 := off(q, fy)
            if _look(q2, c) == 0:
                out.append(q2)
    var ql := off(p, fl)
    if _look(ql, c) == 0:
        out.append(ql)
    var sides := [Vector4i(1, 0, 0, 0), Vector4i(-1, 0, 0, 0), Vector4i(0, 0, 0, 1), Vector4i(0, 0, 0, -1)]
    for f in [fy, fl]:
        for sd in sides:
            var qc := off(p, f + sd)
            if _look(qc, c) == 1:
                out.append(qc)


# ---------------------------------------------------------------- thuc hien nuoc di

func apply_move(src: Vector4i, dst: Vector4i) -> Dictionary:
    var prev_winner := winner
    _log = []
    var piece := piece_at(src)
    var c := signi(piece)
    var captured := piece_at(dst)
    if absi(captured) == KING:
        winner = c
        end_cell = dst
        end_src = src
        end_piece = piece
    var placed := piece
    if absi(piece) == PAWN and dst.y == (N - 1 if c == WHITE else 0):
        placed = QUEEN * c
    var a_new := board_at(src.z, src.w).duplicate()
    a_new[idx(src.x, src.y)] = 0
    if src.z == dst.z and src.w == dst.w:
        a_new[idx(dst.x, dst.y)] = placed
        if absi(piece) == KING and absi(dst.x - src.x) == 2:      # nhap thanh: dua Xe sang
            var rx_from := 7 if dst.x > src.x else 0
            var rx_to := 5 if dst.x > src.x else 3
            a_new[idx(rx_from, src.y)] = 0
            a_new[idx(rx_to, src.y)] = ROOK * c
        _rights_after(a_new, piece, src.x, src.y, captured, dst.x, dst.y)
        _push(src.z, src.w, a_new, c)
    else:
        var b_new := board_at(dst.z, dst.w).duplicate()
        b_new[idx(dst.x, dst.y)] = placed
        _rights_after(a_new, piece, src.x, src.y, 0, -1, -1)
        _rights_after(b_new, 0, 0, 0, captured, dst.x, dst.y)
        if absi(piece) == KING or absi(piece) == ROOK:
            b_new[RIGHTS] = b_new[RIGHTS] & ~(3 if c == WHITE else 12)
        _push(src.z, src.w, a_new, c)   # ban xuat phat mat quan
        _push(dst.z, dst.w, b_new, c)   # ban dich nhan quan (co the re nhanh timeline moi)
    return {"entries": _log, "winner": prev_winner}


func _push(l: int, t: int, board: PackedInt32Array, c: int) -> void:
    var d: Dictionary = tl[l]
    if t == head_t(l):
        var boards: Array = d["boards"]
        boards.append(board)
        _log.append([l, 0, c])
    else:
        var nl: int
        if c == WHITE:
            n_white += 1
            nl = n_white
        else:
            n_black += 1
            nl = -n_black
        tl[nl] = {"start": t + 1, "boards": [board], "parent": l}
        _log.append([nl, 1, c])


## Vua cua mau c co the bi bat o luot ke tiep cua doi phuong khong?
@warning_ignore("integer_division")
func in_danger(c: int) -> bool:
    var opp := -c
    for l in active_ls():
        var t := head_t(l)
        if color_at_t(t) != opp:
            continue
        var b := board_at(l, t)
        for i in N * N:
            if b[i] != 0 and signi(b[i]) == opp:
                var p := Vector4i(i % N, i / N, l, t)
                for q in moves_for(p):
                    var v := piece_at(q)
                    if absi(v) == KING and signi(v) == c:
                        return true
    return false


## Tim 1 nuoc cua doi phuong an duoc Vua cua mau c: tra ve [src, dst, quan] hoac [] neu khong co.
@warning_ignore("integer_division")
func find_king_attack(c: int) -> Array:
    var opp := -c
    for l in active_ls():
        var t := head_t(l)
        if color_at_t(t) != opp:
            continue
        var b := board_at(l, t)
        for i in N * N:
            if b[i] != 0 and signi(b[i]) == opp:
                var p := Vector4i(i % N, i / N, l, t)
                for q in moves_for(p):
                    var v := piece_at(q)
                    if absi(v) == KING and signi(v) == c:
                        return [p, q, b[i]]
    return []


## Ket thuc luot. Tra ve "" neu thanh cong, nguoc lai la thong bao loi.
func submit() -> String:
    if not can_submit():
        return "Chưa thể kết thúc: present vẫn ở phía bạn, hãy đi nốt các bảng thuộc present."
    if strict_check and in_danger(turn_color):
        return "Không hợp lệ: Vua của bạn đang bị chiếu!"
    turn_color = -turn_color
    return ""


## Hoan tac dung 1 nuoc di vua apply_move (dung cho AI tim kiem).
func undo_move(tok: Dictionary) -> void:
    var entries: Array = tok["entries"]
    for i in range(entries.size() - 1, -1, -1):
        var e: Array = entries[i]
        var l: int = e[0]
        if e[1] == 0:
            var d: Dictionary = tl[l]
            var boards: Array = d["boards"]
            boards.pop_back()
        else:
            tl.erase(l)
            if e[2] == WHITE:
                n_white -= 1
            else:
                n_black -= 1
    winner = tok["winner"]


func clone() -> RefCounted:
    var g = get_script().new()
    g.tl = tl.duplicate(true)
    g.n_white = n_white
    g.n_black = n_black
    g.turn_color = turn_color
    g.winner = winner
    g.strict_check = strict_check
    return g


func snapshot() -> Dictionary:
    return {"tl": tl.duplicate(true), "nw": n_white, "nb": n_black, "tc": turn_color, "w": winner}


func restore(s: Dictionary) -> void:
    end_cell = Vector4i(-1, -1, -1, -1)
    end_src = Vector4i(-1, -1, -1, -1)
    end_piece = 0
    tl = (s["tl"] as Dictionary).duplicate(true)
    n_white = s["nw"]
    n_black = s["nb"]
    turn_color = s["tc"]
    winner = s["w"]
