extends RefCounted
## AI nho cho quan Den ("bo nao" AIBrain).
## - Tim kiem nong, chia nho theo khung hinh (~5ms/khung) nen khong lag.
## - Hoc qua cac van: gia tri quan (w), trong so vi tri (pw), tri nho nuoc di thang/thua (mem).
## - Cap do bat dau o cap 1, tang theo kinh nghiem. Luu o user://chess5d_brain_v2.json

const Game5D = preload("res://game.gd")

const SAVE_PATH := "user://chess5d_brain_v2.json"
const BASE_W := [1.0, 3.0, 3.2, 5.0, 9.0]            # Tot, Ma, Tuong, Xe, Hau (don vi: 1 tot)
const BASE_PW := [0.25, 0.25, 0.20, 0.30, 0.60, 0.10]
const KING_VAL := 20000.0
const POS_SCALE := 150.0
const MAX_STEPS := 10
const MAX_LEVEL := 10
const BUDGET_US := 5000        # toi da ~5ms cho moi khung hinh
const THINK_US := 3000000      # toi da ~3s cho 1 luot
const MEM_LIMIT := 4000

# ---- tri nho (luu file)
var w: Array = BASE_W.duplicate()      # gia tri quan da hoc
var pw: Array = BASE_PW.duplicate()    # trong so dac trung vi tri
var mem: Dictionary = {}               # "poskey|movekey" -> [thang, thua, so_lan]
var xp := 0
var games := 0
var wins := 0

# ---- nhat ky van dang choi (main.gd goi .size() / .clear())
var trajectory: Array = []             # moi luot AI: {"f": [11 so], "m": [[poskey, movekey], ...]}

var g: Game5D                          # ban sao dang tinh toan
var _pending: Array = []
var _vec: Array = []
var _running := false
var _cancel_req := false
var _tree: SceneTree
var _t0 := 0
var _deadline := 0
var _budget := BUDGET_US       # tu giam khi may cham, tang lai khi muot
var _last_resume := 0


# ===================================================================== tien ich

func level() -> int:
    return clampi(1 + int(sqrt(float(xp + 5 * games) / 12.0)), 1, MAX_LEVEL)   # bat dau o cap 1


## Suc manh tim kiem thuc te. Cap hien thi 1 da choi kha (tuong duong cap 3 cu),
## cap cang cao cang manh. Tach rieng de cap 1 van thong minh.
func _eff() -> int:
    return level() + 2


func cancel() -> void:
    _cancel_req = true


func _dead() -> bool:
    return _cancel_req


func _time_up() -> bool:
    return Time.get_ticks_usec() > _deadline


func _yield() -> void:
    await _tree.process_frame
    var now := Time.get_ticks_usec()
    var frame_us := now - _last_resume          # ca khung (AI + ve), do thuc te tren may
    _last_resume = now
    _t0 = now
    if frame_us > 24000:
        _budget = maxi(1200, int(float(_budget) * 0.75))
    elif frame_us < 17000:
        _budget = mini(BUDGET_US, int(float(_budget) * 1.1) + 100)


func _center(x: int, y: int) -> float:
    return 3.5 - maxf(absf(float(x) - 3.5), absf(float(y) - 3.5))


func _mkey(s: Vector4i, d: Vector4i) -> String:
    return "%d,%d,%d,%d>%d,%d,%d,%d" % [s.x, s.y, s.z, s.w, d.x, d.y, d.z, d.w]


func _pos_key() -> int:
    var h := 2166136261
    for l in g.active_ls():
        var t: int = g.head_t(l)
        h = ((h ^ (int(l) + 17)) * 16777619) & 0xFFFFFFFF
        h = ((h ^ (t + 3)) * 16777619) & 0xFFFFFFFF
        var b := g.board_at(l, t)
        for i in b.size():
            h = ((h ^ (b[i] + 7)) * 16777619) & 0xFFFFFFFF
    return h


func _book(pk: String, mk: String) -> float:
    var m: Variant = mem.get(pk + "|" + mk)
    if m == null:
        return 0.0
    var arr: Array = m
    return (float(arr[0]) - float(arr[1])) / (float(arr[2]) + 2.0)


# ===================================================================== luu / hoc

func load_brain() -> void:
    if not FileAccess.file_exists(SAVE_PATH):
        return
    var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
    if f == null:
        return
    var data: Variant = JSON.parse_string(f.get_as_text())
    f.close()
    if typeof(data) != TYPE_DICTIONARY:
        return
    var d: Dictionary = data
    var pv: Variant = d.get("pv", [])
    if typeof(pv) == TYPE_ARRAY and (pv as Array).size() == 5:
        w = (pv as Array).duplicate()
    var pp: Variant = d.get("pw", [])
    if typeof(pp) == TYPE_ARRAY and (pp as Array).size() == 6:
        pw = (pp as Array).duplicate()
    var m: Variant = d.get("mem", {})
    if typeof(m) == TYPE_DICTIONARY:
        mem = m
    xp = int(d.get("xp", 0))
    games = int(d.get("games", 0))
    wins = int(d.get("wins", 0))


func save_brain() -> void:
    var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
    if f == null:
        return
    f.store_string(JSON.stringify({"pv": w, "pw": pw, "mem": mem, "xp": xp, "games": games, "wins": wins}))
    f.close()


func reset() -> void:
    w = BASE_W.duplicate()
    pw = BASE_PW.duplicate()
    mem = {}
    xp = 0
    games = 0
    wins = 0
    trajectory.clear()
    _pending.clear()
    save_brain()


## Ghi lai the co sau khi AI vua di xong (main.gd goi sau khi submit thanh cong).
func record(gm: Game5D) -> void:
    g = gm
    _eval()
    trajectory.append({"f": _vec.duplicate(), "m": _pending.duplicate()})
    _pending.clear()
    xp += 1
    if xp % 5 == 0:
        save_brain()


## result: +1 = Den (AI) thang, -1 = AI thua.
func learn(result: int) -> void:
    games += 1
    if result > 0:
        wins += 1
    var n := trajectory.size()
    for i in n:
        var entry: Dictionary = trajectory[i]
        var f: Array = entry["f"]
        var z := 0.0
        for k in 5:
            z += float(w[k]) / 9.0 * float(f[k])
        for k in 6:
            z += 0.5 * float(pw[k]) * float(f[5 + k])
        var p := tanh(z)
        var gain := (float(result) - p) * (1.0 - p * p) * float(i + 1) / float(n)
        for k in 5:
            w[k] = clampf(float(w[k]) + 0.1 * gain * float(f[k]), float(BASE_W[k]) * 0.6, float(BASE_W[k]) * 1.7)
        for k in 6:
            pw[k] = clampf(float(pw[k]) + 0.5 * gain * float(f[5 + k]), -1.0, 3.0)
        for mv in entry["m"]:
            var key: String = str(mv[0]) + "|" + str(mv[1])
            var m: Array = mem.get(key, [0, 0, 0])
            m[2] = float(m[2]) + 1.0
            if result > 0:
                m[0] = float(m[0]) + 1.0
            else:
                m[1] = float(m[1]) + 1.0
            mem[key] = m
    _prune_memory()
    save_brain()


func _prune_memory() -> void:
    if mem.size() <= MEM_LIMIT:
        return
    var items: Array = []
    for k in mem.keys():
        items.append([k, float(mem[k][2])])
    items.sort_custom(func(a, b): return a[1] < b[1])
    for i in 500:
        mem.erase(items[i][0])


# ===================================================================== danh gia

func _around(b: PackedInt32Array, kp: int, sgn: int) -> int:
    if kp < 0:
        return 0
    var n := 0
    var kx := kp % 8
    var ky := kp >> 3
    for dy in range(-1, 2):
        for dx in range(-1, 2):
            if dx == 0 and dy == 0:
                continue
            var x := kx + dx
            var y := ky + dy
            if x < 0 or x > 7 or y < 0 or y > 7:
                continue
            var v := b[y * 8 + x]
            if v != 0 and signi(v) == sgn and absi(v) != 6:
                n += 1
    return n


## Diem tu goc nhin Den (duong = tot cho Den). Dong thoi cap nhat _vec (11 dac trung, dung de hoc).
func _eval() -> float:
    var dsum := [0.0, 0.0, 0.0, 0.0, 0.0]
    var kdiff := 0.0
    var adv := 0.0
    var cen := 0.0
    var ksf := 0.0
    var dev := 0.0
    var ahead := 0
    var heads := 0
    for l in g.active_ls():
        heads += 1
        var b := g.board_at(l, g.head_t(l))
        var cnt := [0, 0, 0, 0, 0, 0, 0]       # chi so theo loai quan: den - trang
        var kb := -1
        var kw := -1
        var mb := 0.0
        var mw := 0.0
        for i in 64:
            var v: int = b[i]
            if v == 0:
                continue
            var a := absi(v)
            var x := i % 8
            var y := i >> 3
            if v < 0:
                cnt[a] += 1
                if a == 6:
                    kb = i
                elif a == 1:
                    adv += float(6 - y)
                    cen += _center(x, y)
                elif a == 2 or a == 3:
                    cen += _center(x, y)
                    if y != 7:
                        dev += 1.0
            else:
                cnt[a] -= 1
                if a == 6:
                    kw = i
                elif a == 1:
                    adv -= float(y - 1)
                    cen -= _center(x, y)
                elif a == 2 or a == 3:
                    cen -= _center(x, y)
                    if y != 0:
                        dev -= 1.0
        var diff := 0.0
        for k in 5:
            dsum[k] += float(cnt[k + 1])
            diff += float(cnt[k + 1]) * float(w[k])
        kdiff += float(cnt[6])
        ksf += float(_around(b, kb, -1) - _around(b, kw, 1))
        if diff > 0.5:
            ahead += 1
        elif diff < -0.5:
            ahead -= 1
    var hn := float(maxi(heads, 1))
    var scale := [8.0, 2.0, 2.0, 2.0, 1.0]
    _vec = []
    for k in 5:
        _vec.append(clampf(float(dsum[k]) / (hn * float(scale[k])), -1.0, 1.0))
    _vec.append(clampf(adv / (10.0 * hn), -1.0, 1.0))
    _vec.append(clampf(cen / (12.0 * hn), -1.0, 1.0))
    _vec.append(clampf(ksf / (4.0 * hn), -1.0, 1.0))
    _vec.append(clampf(dev / (4.0 * hn), -1.0, 1.0))
    _vec.append(clampf(float(ahead) / hn, -1.0, 1.0))
    _vec.append(clampf(float(g.n_black - g.n_white) / 3.0, -1.0, 1.0))
    var mat := 0.0
    for k in 5:
        mat += float(dsum[k]) * float(w[k]) * 100.0
    mat += kdiff * KING_VAL
    var pos := 0.0
    for k in 6:
        pos += float(pw[k]) * float(_vec[5 + k])
    return mat + POS_SCALE * pos


func _pval(a: int) -> float:
    if a >= 6:
        return KING_VAL
    return float(w[a - 1]) * 100.0


## Cac nuoc bat quan (chi tinh bang dau timeline) cua `color`: [[gia tri, src, dst, gia tri quan di], ...]
func _captures_for(color: int, all: bool = false) -> Array:
    var out: Array = []
    for l in g.active_ls():
        var t: int = g.head_t(l)
        if g.color_at_t(t) != color:
            continue
        var b := g.board_at(l, t)
        for i in 64:
            var v: int = b[i]
            if v == 0 or signi(v) != color:
                continue
            var src := Vector4i(i % 8, i >> 3, l, t)
            for dst in g.moves_for(src):
                var tv := g.piece_at(dst)
                if tv != 0 and dst.w == g.head_t(dst.z):
                    out.append([_pval(absi(tv)), src, dst, _pval(absi(v))])
                elif all:
                    out.append([0.0, src, dst, _pval(absi(v))])
            if Time.get_ticks_usec() - _t0 > _budget:
                await _yield()
                if _dead():
                    return out
    return out


## Thiet hai rong toi da neu Trang an quan, sau khi tru phan Den an lai (tim sau 3 nuoc).
func _refine_penalty(caps: Array) -> float:
    var list: Array = caps.duplicate()
    list.sort_custom(func(x, y): return float(x[0]) - float(x[3]) * 0.1 > float(y[0]) - float(y[3]) * 0.1)
    var worst := 0.0
    var n := mini(list.size(), 4)
    for j in n:
        var cp: Array = list[j]
        if float(cp[0]) <= 0.0:
            continue
        var tok: Dictionary = g.apply_move(cp[1], cp[2])
        var back: Array = await _captures_for(Game5D.BLACK)
        if _dead():
            return worst
        g.undo_move(tok)
        var bg := 0.0
        for bc in back:
            bg = maxf(bg, float(bc[0]))
        worst = maxf(worst, float(cp[0]) - bg)
    return worst


## Tim kiem 2-3 nuoc: sau nuoc cua Den, Trang chon nuoc dap tra tot nhat (diem thap nhat cho Den).
## Cap >= 5: neu Trang an quan thi cong them phan Den an lai (tranh doi quan lo).
func _reply_min(moves: Array, width: int, lvl: int) -> float:
    var rep: Array = []
    for m in moves:
        var src: Vector4i = m[1]
        var dst: Vector4i = m[2]
        var sc := 0.0
        var is_cap := float(m[0]) > 0.0
        if is_cap:
            sc = float(m[0]) - float(m[3]) * 0.05
        if dst.z != src.z or dst.w != src.w:
            sc += 6.0
        sc += (_center(dst.x, dst.y) - _center(src.x, src.y)) * 4.0
        rep.append([sc, src, dst, is_cap])
    rep.sort_custom(func(x, y): return x[0] > y[0])
    var worst := INF
    var recaps := 0
    for j in mini(width, rep.size()):
        var r: Array = rep[j]
        var tok: Dictionary = g.apply_move(r[1], r[2])
        var e := _eval()
        if lvl >= 5 and r[3] and recaps < 3:
            recaps += 1
            var back: Array = await _captures_for(Game5D.BLACK)
            if _dead():
                return worst
            var bg := 0.0
            for bc in back:
                bg = maxf(bg, float(bc[0]))
            e += minf(bg, 1500.0) * 0.9
        g.undo_move(tok)
        worst = minf(worst, e)
        if Time.get_ticks_usec() - _t0 > _budget:
            await _yield()
            if _dead():
                return worst
    return worst


# ===================================================================== chon nuoc

## Tra ve [diem, ung_vien, dac_trung] hoac null. ung_vien = [diem_so_bo, src, dst, movekey]
func _choose(pk: String, banned: Dictionary, lvl: int) -> Variant:
    var cands: Array = []
    var noise := maxf(0.0, 30.0 - 4.0 * float(lvl))
    for l in g.active_ls():
        var t: int = g.head_t(l)
        if g.color_at_t(t) != Game5D.BLACK:
            continue
        var b := g.board_at(l, t)
        for i in 64:
            var v: int = b[i]
            if v >= 0:
                continue
            var src := Vector4i(i % 8, i >> 3, l, t)
            var a := absi(v)
            var cs := _center(src.x, src.y)
            for dst in g.moves_for(src):
                var mk := _mkey(src, dst)
                if banned.has(mk):
                    continue
                var sc := (_center(dst.x, dst.y) - cs) * 6.0 + _book(pk, mk) * 60.0 + randf() * noise
                var tv := g.piece_at(dst)
                if tv != 0:
                    sc += _pval(absi(tv)) - _pval(a) * 0.05
                if a == 1:
                    sc += float(src.y - dst.y) * 5.0
                if dst.z != src.z or dst.w != src.w:
                    sc += 8.0
                cands.append([sc, src, dst, mk])
            if Time.get_ticks_usec() - _t0 > _budget:
                await _yield()
                if _dead():
                    return null
    if cands.is_empty():
        return null
    cands.sort_custom(func(x, y): return x[0] > y[0])

    var k := 4 + 3 * lvl
    var scored: Array = []
    var ci := 0
    while ci < cands.size():
        if ci >= k and not scored.is_empty():
            break
        if ci >= 3 and not scored.is_empty() and _time_up():
            break
        var c: Array = cands[ci]
        ci += 1
        var tok: Dictionary = g.apply_move(c[1], c[2])
        var is_final := g.can_submit()
        var sc2 := _eval()
        var feat := _vec.duplicate()
        var legal := true
        if g.winner != 0:
            sc2 += 100000.0                       # an duoc Vua
        elif is_final:
            var caps: Array = await _captures_for(Game5D.WHITE, lvl >= 3)
            if _dead():
                return null
            var worst := 0.0
            var king_hit := false
            for cp in caps:
                worst = maxf(worst, float(cp[0]))
                if float(cp[0]) >= KING_VAL:
                    king_hit = true
            if king_hit and g.strict_check:
                legal = false                     # de Vua bi chieu
            else:
                var pen := worst * 0.5
                if lvl >= 3 and not _time_up() and not caps.is_empty():
                    var rm: float = await _reply_min(caps, 3 + lvl, lvl)
                    if _dead():
                        return null
                    if rm < INF:
                        sc2 = rm                  # diem sau khi Trang dap tra tot nhat
                        pen = 0.0
                sc2 -= pen
        if legal:
            sc2 += _book(pk, c[3]) * 80.0
            scored.append([sc2, c, feat])
        g.undo_move(tok)
        if Time.get_ticks_usec() - _t0 > _budget:
            await _yield()
            if _dead():
                return null
    if scored.is_empty():
        return null
    scored.sort_custom(func(x, y): return x[0] > y[0])
    var pick: Array = scored[0]
    var explore := maxf(0.0, 0.20 - 0.03 * float(lvl))   # cap thap hay "sai lam" hon (da giam)
    if scored.size() > 1 and randf() < explore:
        pick = scored[randi() % mini(3, scored.size())]
    return pick


## Tinh ca luot cua Den tren ban sao `clone`. Tra ve [[src, dst], ...]; rong = het nuoc hop le.
func plan_turn(clone: Game5D, tree: SceneTree) -> Array:
    while _running:
        _cancel_req = true
        await tree.process_frame
    _cancel_req = false
    _running = true
    _tree = tree
    var plan: Array = await _think(clone)
    _running = false
    if _cancel_req:
        return []
    return plan


func _think(clone: Game5D) -> Array:
    g = clone
    _pending.clear()
    _t0 = Time.get_ticks_usec()
    _deadline = _t0 + THINK_US
    _last_resume = _t0
    var lvl := _eff()
    _deadline = _t0 + mini(THINK_US + lvl * 150000, 4500000)
    var snap := g.snapshot()
    var banned: Dictionary = {}
    for attempt in 3:
        g.restore(snap)
        var plan: Array = []
        var keys: Array = []
        var failed := false
        while not g.can_submit():
            if g.winner != 0:
                break
            if plan.size() >= MAX_STEPS:
                failed = true
                break
            var pk := str(_pos_key())
            var res: Variant = await _choose(pk, banned if plan.is_empty() else {}, lvl)
            if _dead():
                return []
            if res == null:
                failed = true
                break
            var cand: Array = (res as Array)[1]
            g.apply_move(cand[1], cand[2])
            plan.append([cand[1], cand[2]])
            keys.append([pk, cand[3]])
        if not failed and (g.winner != 0 or not (g.strict_check and g.in_danger(Game5D.BLACK))):
            _pending = keys
            return plan
        if plan.is_empty():
            break
        banned[_mkey(plan[0][0], plan[0][1])] = true
    return []
